var tabs = document.getElementsByClassName('tab')[0].getElementsByTagName('li'),
    contents = document.getElementsByClassName('tab_content')[0].children;


    (function changeTab(tab) {
        for(var i = 0, len = tabs.length; i < len; i++) {
            tabs[i].onclick = showTab;
        }
    })();

    var Tabs = document.getElementsByClassName('tab_margin');
    for (var i = 0; i < Tabs.length; i++) {
        Tabs[i].addEventListener('click', showTab, false) //onclick = showTab();
    }


    function showTab() {
        for(var i = 0, len = Tabs.length; i < len; i++) {
                
            if(Tabs[i] === this) {
                // tabs[i].className = 'tabin';
                location.href =  this.attributes[1].nodeValue;
            } 
        }
    }

    var subTabs = document.getElementsByClassName('sub_span');
    for (var i = 0; i < subTabs.length; i++) {
        subTabs[i].addEventListener('click', showsubTab, false) //onclick = showTab();
    }
    // console.log(subTabs)


    function showsubTab() {
        for(var i = 0, len = subTabs.length; i < len; i++) {
                
            if(subTabs[i] === this) {
                // console.log(this)
                // tabs[i].className = 'tabin';
                location.href =  this.attributes[1].nodeValue;
            } 
        }
    }

    var subTabs1 = document.getElementsByClassName('sub_span1');
    for (var i = 0; i < subTabs1.length; i++) {
        subTabs1[i].addEventListener('click', showsub1Tab, false) //onclick = showTab();
    }
    // console.log(subTabs1)


    function showsub1Tab() {
        for(var i = 0, len = subTabs1.length; i < len; i++) {
                
            if(subTabs1[i] === this) {
                // console.log(this)
                // tabs[i].className = 'tabin';
                location.href =  this.attributes[1].nodeValue;
            } 
        }
    }

    var subTabs2 = document.getElementsByClassName('sub_span2');
    for (var i = 0; i < subTabs2.length; i++) {
        subTabs2[i].addEventListener('click', showsub2Tab, false) //onclick = showTab();
    }
    // console.log(subTabs2)


    function showsub2Tab() {
        for(var i = 0, len = subTabs2.length; i < len; i++) {
            if(subTabs2[i] === this) {
                // console.log(this)
                // tabs[i].className = 'tabin';
                location.href =  this.attributes[1].nodeValue;
            } 
        }
    }

// Function to alert show/hidden
function show_alerts(event) {
    let oevent = event || window.event
    if (document.all) {
        oevent.cancelBubble = true
    } else {
        oevent.stopPropagation()
    }
    if (document.getElementById('alerts_content_id').style.display === 'none' || document.getElementById('alerts_content_id').style.display === '') {
        document.getElementById('alerts_content_id').style.display = 'block'
        document.getElementById('show_qc_buttom').style.display = 'none'
        document.getElementById('hidden_qc_buttom').style.display = 'block'
    } else {
        document.getElementById('alerts_content_id').style.display = 'none'
        document.getElementById('show_qc_buttom').style.display = 'block'
        document.getElementById('hidden_qc_buttom').style.display = 'none'
    }
}


document.getElementById('alerts_content_id').onclick = function (event) {
    let oevent = event || window.event
    oevent.stopPropagation()
}

// Function to zoom img with click
function openImg(e){
    document.getElementById("pop-img").src = e;
    var targit = document.getElementById("pop-box");
    if (targit.style.display == "none" || targit.style.display == ""){
        targit.style.display = "flex";
    } else{
        targit.style.display = "none";
    }
}

// Function to zoom img with click big
function openImgBig(e){
    document.getElementById("pop-img-big").src = e;
    var targit = document.getElementById("pop-box-big");
    if (targit.style.display == "none" || targit.style.display == ""){
        targit.style.display = "flex";
    } else{
        targit.style.display = "none";
    }
}

