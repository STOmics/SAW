
PLOT = document.getElementById('proportion_plot');
var trace_proportion = {
x: [178744, 179686, 183871, 192556, 197811, 224252, 232832, 249019, 256482, 294716, 309505, 309751, 313383, 313768, 339304, 342476, 357590, 362779, 391282, 425818, 431270, 439504, 441965, 443473, 501698, 503152, 503232, 509692, 520703, 532534, 538428, 542193, 544488, 595878, 611055, 615006, 636129, 643086, 649425, 675534, 678563, 692121, 734062, 734565, 747087, 748906, 759039, 764335, 802267, 814959, 854961, 891048, 905507, 916404, 920075, 940492, 940737, 952050, 973833, 995766, 999440, 1000164, 1013325, 1113450, 1138712, 1256046, 1267698, 1270987, 1287486, 1325801, 1355827, 1370614, 1396399, 1407529, 1417168, 1428558, 1628170, 1655665, 1955735, 1974507, 2299724, 2445818, 2623075, 2872468, 3039768, 3122857, 3442370, 3670120, 3842740, 3901293, 3957901, 3997304, 4164532, 4207892, 4927474, 5656092, 7052408, 11628094, 15416802, 19264971],
y: ['TER119_Ms', 'Ly-49A_Ms', 'CD31_Ms', 'TCR_r_d_Ms', 'CD55_Ms', 'NK1_1_Ms', 'FceRIa_Ms', 'CD103_Ms', 'CD73_Ms', 'CD138_Ms', 'CD1d_Ms', 'Ly49H_Ms', 'Tim4_Ms', 'CD371_Ms', 'Ly6G_Ms', 'CD226_Ms_10E5', 'CD49a_Ms', 'CD170_Ms', 'CD366_Ms', 'CD43_Ms', 'CD44_MsHu', 'CD38_Ms', 'CD94_Ms', 'IL-33Ra_Ms', 'CD79b_Ms', 'KLRG1_MsHu', 'Integrin_b7_MsHu', 'F4_80_Ms', 'CD150_Ms', 'CD24_Ms', 'CD120b_Ms', 'CD301b_Ms', 'CD159a_Ms', 'CD301a_Ms', 'CD106_Ms', 'CD272_Ms', 'CD22_Ms', 'CD49d_Ms', 'CD270_Ms', 'CD40_Ms', 'CD41_Ms', 'CD186_Ms', 'Ly6C_Ms', 'CD357_Ms', 'CD11c_Ms', 'CD223_Ms', 'CD200R_Ms', 'CD274_Ms', 'CD71_Ms', 'CD86_Ms', 'CD279_Ms', 'CD304_Ms', 'CD155_Ms', 'Ly108_Ms', 'CD127_Ms', 'CD36_Ms', 'CD27_MsHu', 'CD102_Ms', 'I_A_I_E_Ms', 'CD134_Ms', 'CD81_Ms', 'CD54_Ms', 'CD85k_Ms', 'CD172a_Ms', 'CD169_Ms', 'CD63_Ms', 'CD48_Ms', 'JAML_Ms', 'CD205_Ms', 'CD200_Ms', 'CD11a_Ms', 'CD69_Ms', 'CD185_Ms', 'CD137_Ms', 'CD160_Ms', 'CD83_Ms', 'IgM_Ms', 'CD64_Ms', 'CD20_Ms', 'CD199_Ms', 'CD26_Ms', 'CD317_Ms', 'CD90_2_Ms', 'XCR1_Ms', 'CX3CR1_Ms', 'CD29_Ms', 'VISTA_Ms', 'CD4_Ms', 'Ly6A_E_Ms', 'CD45_2_Ms', 'CD107a_Ms', 'CD8a_Ms', 'CD5_Ms', 'TCR_b_Ms', 'CD8b_Ms', 'CD2_Ms', 'CD68_Ms', 'CD49f_Hu', 'CD45_Ms', 'CD3_Ms'] ,
text:['0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '0%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '1%', '2%', '2%', '2%', '2%', '2%', '2%', '2%', '2%', '2%', '2%', '2%', '3%', '3%', '4%', '7%', '9%', '11%'],
marker: {
    color: 'rgba(183,127,221,0.6)',
    width: 2
  },
    orientation: 'h',
    type: 'bar'
}
let customHeight = trace_proportion.x.length*40
var layout_proportion = {
    height	:	customHeight,
    width:1000,
    title: {text:'Proprotion of Protein','font':{'color':'black', 'size':20}},
    margin: {
        l: 200,
        r: 80,
        t: 50,
        b: 70
      },
}

var config_proportion = {
    toImageButtonOptions: {
        format: 'png', // one of png, svg, jpeg, webp
        filename: 'custom_image',
        height: 600,
        width: 600,
        scale: 5 // Multiply title/legend/axis/canvas sizes by this factor
    },
    scrollZoom:false,
    displaylogo:false,
    modeBarButtonsToRemove:["hoverClosestCartesian","hoverCompareCartesian","toggleSpikelines","autoScale2d","lasso2d","select2d"]
};
var data_proportion = [trace_proportion]
Plotly.newPlot(PLOT, data_proportion, layout_proportion,config_proportion);
