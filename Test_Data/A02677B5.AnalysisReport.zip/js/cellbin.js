// Function to show cell bin
function show_cellBin (event) {
    let oevent = event || window.event
    if (document.all) {
        oevent.cancelBubble = true
    } else {
        oevent.stopPropagation()
    }
    if (document.getElementById('div_explain_cellBin').style.display === 'none' || document.getElementById('div_explain_cellBin').style.display === '') {
        document.getElementById('div_explain_cellBin').style.display = 'block'
    } else {
        document.getElementById('div_explain_cellBin').style.display = 'none'
    }
}
document.onclick = function () {
    document.getElementById('div_explain_cellBin').style.display = 'none'
}
document.getElementById('div_explain_cellBin').onclick = function (event) {
    let oevent = event || window.event
    oevent.stopPropagation()
}

// Function to show cell bin stats
function show_cell_bin_stats (event) {{
    let oevent = event || window.event
    if (document.all) {{
        oevent.cancelBubble = true
    }} else {{
        oevent.stopPropagation()
    }}
    if (document.getElementById('div_explain_cell_bin_stats').style.display === 'none' || document.getElementById('div_explain_cell_bin_stats').style.display === '') {{
        document.getElementById('div_explain_cell_bin_stats').style.display = 'block'
    }} else {{
        document.getElementById('div_explain_cell_bin_stats').style.display = 'none'
    }}
}}
document.onclick = function () {{
    document.getElementById('div_explain_cell_bin_stats').style.display = 'none'
}}
document.getElementById('div_explain_cell_bin_stats').onclick = function (event) {{
    let oevent = event || window.event
    oevent.stopPropagation()
}}

// Function to show cell bin clustering
function show_cellBin_clustering (event) {
    let oevent = event || window.event
    if (document.all) {
        oevent.cancelBubble = true
    } else {
        oevent.stopPropagation()
    }
    if (document.getElementById('div_explain_cellBin_clustering').style.display === 'none' || document.getElementById('div_explain_cellBin_clustering').style.display === '') {
        document.getElementById('div_explain_cellBin_clustering').style.display = 'block'
    } else {
        document.getElementById('div_explain_cellBin_clustering').style.display = 'none'
    }
}
document.onclick = function () {
    document.getElementById('div_explain_cellBin_clustering').style.display = 'none'
}
document.getElementById('div_explain_cellBin_clustering').onclick = function (event) {
    let oevent = event || window.event
    oevent.stopPropagation()
}

// Function to plot cluster square bin
function cluster_cell_ssdna() {
    var update = {
        'marker.opacity': 0,
    };
    Plotly.restyle(divCellCluster, update);    
    document.getElementById('range_cell_cluster').value = 0;
}

// Function to plot cluster square bin ssDNA
function cell_cluster() {
    var update = {
        'marker.opacity': 1,
    };
    Plotly.restyle(divCellCluster, update);
    document.getElementById('range_cell_cluster').value = 1;
}