// Function to show image stitching
function show_stitching (event) {
    let oevent = event || window.event
    if (document.all) {
        oevent.cancelBubble = true
    } else {
        oevent.stopPropagation()
    }
    if (document.getElementById('div_explain_stitching').style.display === 'none' || document.getElementById('div_explain_stitching').style.display === '') {
        document.getElementById('div_explain_stitching').style.display = 'block'
    } else {
        document.getElementById('div_explain_stitching').style.display = 'none'
    }
}
document.onclick = function () {
    document.getElementById('div_explain_stitching').style.display = 'none'
}
document.getElementById('div_explain_stitching').onclick = function (event) {
    let oevent = event || window.event
    oevent.stopPropagation()
}

// Function to show image qc
function show_qc (event) {
    let oevent = event || window.event
    if (document.all) {
        oevent.cancelBubble = true
    } else {
        oevent.stopPropagation()
    }
    if (document.getElementById('div_explain_qc').style.display === 'none' || document.getElementById('div_explain_qc').style.display === '') {
        document.getElementById('div_explain_qc').style.display = 'block'
    } else {
        document.getElementById('div_explain_qc').style.display = 'none'
    }
}
document.onclick = function () {
    document.getElementById('div_explain_qc').style.display = 'none'
}
document.getElementById('div_explain_qc').onclick = function (event) {
    let oevent = event || window.event
    oevent.stopPropagation()
}

// Function to show image registration
function show_registration (event) {
    let oevent = event || window.event
    if (document.all) {
        oevent.cancelBubble = true
    } else {
        oevent.stopPropagation()
    }
    if (document.getElementById('div_explain_registration').style.display === 'none' || document.getElementById('div_explain_registration').style.display === '') {
        document.getElementById('div_explain_registration').style.display = 'block'
    } else {
        document.getElementById('div_explain_registration').style.display = 'none'
    }
}
document.onclick = function () {
    document.getElementById('div_explain_registration').style.display = 'none'
}
document.getElementById('div_explain_registration').onclick = function (event) {
    let oevent = event || window.event
    oevent.stopPropagation()
}

// Function to show image heatmap left
function show_image_left (event) {
    let oevent = event || window.event
    if (document.all) {
        oevent.cancelBubble = true
    } else {
        oevent.stopPropagation()
    }
    if (document.getElementById('div_explain_image_left').style.display === 'none' || document.getElementById('div_explain_image_left').style.display === '') {
        document.getElementById('div_explain_image_left').style.display = 'block'
    } else {
        document.getElementById('div_explain_image_left').style.display = 'none'
    }
}
document.onclick = function () {
    document.getElementById('div_explain_image_left').style.display = 'none'
}
document.getElementById('div_explain_image_left').onclick = function (event) {
    let oevent = event || window.event
    oevent.stopPropagation()
}

// Function to show image heatmap right
function show_image_right (event) {
    let oevent = event || window.event
    if (document.all) {
        oevent.cancelBubble = true
    } else {
        oevent.stopPropagation()
    }
    if (document.getElementById('div_explain_image_right').style.display === 'none' || document.getElementById('div_explain_image_right').style.display === '') {
        document.getElementById('div_explain_image_right').style.display = 'block'
    } else {
        document.getElementById('div_explain_image_right').style.display = 'none'
    }
}
document.onclick = function () {
    document.getElementById('div_explain_image_right').style.display = 'none'
}
document.getElementById('div_explain_image_right').onclick = function (event) {
    let oevent = event || window.event
    oevent.stopPropagation()
}